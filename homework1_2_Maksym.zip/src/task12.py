import numpy as np

def decompose_matrix(M):
    T = M[0:3, 3]
    
    c1, c2, c3 = M[0:3, 0], M[0:3, 1], M[0:3, 2]
    S = np.array([np.linalg.norm(c1), np.linalg.norm(c2), np.linalg.norm(c3)])
    
    R = np.zeros((3, 3))
    R[:, 0] = c1 / S[0]
    R[:, 1] = c2 / S[1]
    R[:, 2] = c3 / S[2]
    
    trace = np.trace(R)
    angle = np.arccos(np.clip((trace - 1) / 2, -1, 1))
    
    axis = np.array([
        R[2, 1] - R[1, 2],
        R[0, 2] - R[2, 0],
        R[1, 0] - R[0, 1]
    ])
    if np.linalg.norm(axis) > 1e-6:
        axis = axis / np.linalg.norm(axis)
    else:
        axis = np.array([1, 0, 0])
        
    return T, S, np.degrees(angle), axis

M_task = np.array([
    [1.0, 0.0,   0.0,   4.0],
    [0.0, 0.866, -0.5, -2.0],
    [0.0, 0.5,   0.866, 1.0],
    [0.0, 0.0,   0.0,   1.0]
])

T, S, angle, axis = decompose_matrix(M_task)
print(f"Translation: {T}\nScale: {S}\nAngle: {angle:.2f}°\nAxis: {axis}")