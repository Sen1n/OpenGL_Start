import matplotlib
matplotlib.use("Agg")
import numpy as np
import random
from src.engine.model.Model import Model
from src.engine.model.SimplePolygon import SimplePolygon
from src.engine.scene.Scene import Scene

class Tetrahedron(Model):
    def __init__(self, alpha=1.0, color="cyan", edge_color="blue"):
        super().__init__()
        self.polygons = []
        v = [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]] # Вершини
        faces = [
            [v[0], v[1], v[2]], # Основа XY
            [v[0], v[1], v[3]], # Грань XZ
            [v[0], v[2], v[3]], # Грань YZ
            [v[1], v[2], v[3]]  # Похила грань
        ]
        for face in faces:
            self.polygons.append(SimplePolygon(*face, color=color, edgecolor=edge_color, alpha=alpha))

    def draw_model(self, plt_axis):
        for polygon in self.polygons:
            polygon.transformation = self.transformation
            polygon.pivot(self._pivot)
            polygon.draw(plt_axis)

def get_random_rotation_matrix():
    angle = random.uniform(10, 90)
    axis = np.array([random.uniform(-1, 1) for _ in range(3)])
    axis /= np.linalg.norm(axis) # Нормалізація
    
    theta = np.radians(angle)
    c, s = np.cos(theta), np.sin(theta)
    C = 1 - c
    R = np.array([
        [c + axis[0]**2 * C, axis[0]*axis[1]*C - axis[2]*s, axis[0]*axis[2]*C + axis[1]*s, 0],
        [axis[1]*axis[0]*C + axis[2]*s, c + axis[1]**2 * C, axis[1]*axis[2]*C - axis[0]*s, 0],
        [axis[2]*axis[0]*C - axis[1]*s, axis[2]*axis[1]*C + axis[0]*s, c + axis[2]**2 * C, 0],
        [0, 0, 0, 1]
    ])
    print(f"Випадковий кут: {angle:.2f}°")
    print(f"Випадкова вісь: {axis}")
    return R

def get_random_translation_matrix():
    v = [random.uniform(-5, 5) for _ in range(3)]
    print(f"Випадковий зсув: {v}")
    return np.array([[1,0,0,v[0]], [0,1,0,v[1]], [0,0,1,v[2]], [0,0,0,1]])

scene = Scene(
    image_size=(10, 10),
    coordinate_rect=(-6, -6, -6, 6, 6, 6),
    title="Завдання 5: Рандомізований Тетраедр",
    grid_show=True
)

R = get_random_rotation_matrix()
T = get_random_translation_matrix()
M = T @ R

tetra_init = Tetrahedron(alpha=0.1, color="grey")
tetra_final = Tetrahedron(alpha=0.8, color="red", edge_color="darkred")
tetra_final.transformation = M

scene["initial"] = tetra_init
scene["final"] = tetra_final

scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task5_visualization.png")

print("\nФінальна матриця M:\n", M)