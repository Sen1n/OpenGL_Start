import numpy as np

def get_rot_x(a):
    c, s = np.cos(np.radians(a)), np.sin(np.radians(a))
    return np.array([[1,0,0],[0,c,-s],[0,s,c]])

def get_rot_y(a):
    c, s = np.cos(np.radians(a)), np.sin(np.radians(a))
    return np.array([[c,0,s],[0,1,0],[-s,0,c]])

def get_rot_z(a):
    c, s = np.cos(np.radians(a)), np.sin(np.radians(a))
    return np.array([[c,-s,0],[s,c,0],[0,0,1]])

Ma = get_rot_z(60) @ get_rot_y(45) @ get_rot_x(30)

Mb = get_rot_z(60) @ get_rot_y(45) @ get_rot_x(30)

print("Різниця між матрицями A та Б:\n", np.round(Ma - Mb, 10))