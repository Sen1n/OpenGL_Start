import matplotlib
matplotlib.use("Agg") # Для Codespaces
import numpy as np
from src.engine.model.Cube import Cube
from src.engine.scene.Scene import Scene

def get_rotation_matrix(axis, angle_deg):
    axis = np.array(axis, dtype=float)
    axis /= np.linalg.norm(axis)
    theta = np.radians(angle_deg)
    c, s = np.cos(theta), np.sin(theta)
    C = 1 - c
    return np.array([
        [c + axis[0]**2 * C, axis[0]*axis[1]*C - axis[2]*s, axis[0]*axis[2]*C + axis[1]*s, 0],
        [axis[1]*axis[0]*C + axis[2]*s, c + axis[1]**2 * C, axis[1]*axis[2]*C - axis[0]*s, 0],
        [axis[2]*axis[0]*C - axis[1]*s, axis[2]*axis[1]*C + axis[0]*s, c + axis[2]**2 * C, 0],
        [0, 0, 0, 1]
    ])

def get_translation_matrix(v):
    return np.array([
        [1, 0, 0, v[0]],
        [0, 1, 0, v[1]],
        [0, 0, 1, v[2]],
        [0, 0, 0, 1]
    ])

# Сцена
scene = Scene(
    image_size=(10, 10),
    coordinate_rect=(-1, -3, -1, 7, 5, 5),
    title="Завдання 3: Обертання навколо осі (1,1,1)",
    grid_show=True
)

# Розрахунок матриць
R1 = get_rotation_matrix([0, 0, 1], 60)   # Навколо Z
R2 = get_rotation_matrix([1, 1, 1], 45)   # Навколо діагоналі
T = get_translation_matrix([4, -2, 1])    # Перенесення

# Композиція: спочатку R1, потім R2, потім T
M = T @ R2 @ R1

# Візуалізація
cube_init = Cube(alpha=0.1, color="grey")
cube_final = Cube(alpha=0.7, color="orange", edge_color="darkred")
cube_final.transformation = M

scene["initial"] = cube_init
scene["final"] = cube_final

# Збереження
scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task3_visualization.png")

print("Матриця R1 (Z 60°):\n", R1)
print("\nМатриця R2 (Diag 45°):\n", R2)
print("\nПідсумкова матриця M:\n", M)