import matplotlib
matplotlib.use("Agg")
import numpy as np
from src.engine.model.Cube import Cube
from src.engine.scene.Scene import Scene

def get_translation_matrix(v):
    return np.array([[1, 0, 0, v[0]], [0, 1, 0, v[1]], [0, 0, 1, v[2]], [0, 0, 0, 1]])

def get_scale_matrix(sx, sy, sz):
    return np.array([[sx, 0, 0, 0], [0, sy, 0, 0], [0, 0, sz, 0], [0, 0, 0, 1]])

def get_rotation_z(angle_deg):
    theta = np.radians(angle_deg)
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, -s, 0, 0], [s, c, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])

pivot = (1, 2, 3)

T_to = get_translation_matrix([-p for p in pivot])
T_back = get_translation_matrix(pivot)
S_z = get_scale_matrix(1, 1, 3)

M1 = T_back @ S_z @ T_to

R_z = get_rotation_z(30)
M2 = T_back @ R_z @ T_to

M_total = M2 @ M1

scene = Scene(
    image_size=(10, 10),
    coordinate_rect=(-2, -2, -7, 5, 5, 5),
    title="Завдання 7: Scale & Rotate around Pivot (1,2,3)",
    grid_show=True
)

cube_init = Cube(alpha=0.1, color="grey")
cube_final = Cube(alpha=0.7, color="coral", edge_color="red")

cube_final.pivot(*pivot)
cube_final.show_pivot()
cube_final.transformation = M_total

scene["initial"] = cube_init
scene["final"] = cube_final

scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task7_visualization.png")

print("Матриця трансформації M_total:\n", M_total)