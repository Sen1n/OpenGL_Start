import matplotlib
matplotlib.use("Agg")
import numpy as np
from src.engine.model.SimplePolygon import SimplePolygon
from src.engine.model.Model import Model
from src.engine.scene.Scene import Scene

class Rectangle(Model):
    def __init__(self, vertices, color="cyan", alpha=1.0):
        super().__init__()
        self.polygons = [SimplePolygon(*vertices, color=color, alpha=alpha)]
    
    def draw_model(self, plt_axis):
        for polygon in self.polygons:
            polygon.transformation = self.transformation
            polygon.draw(plt_axis)

def get_rotation_x(angle_deg):
    theta = np.radians(angle_deg)
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1]])

def get_rotation_y(angle_deg):
    theta = np.radians(angle_deg)
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1]])

def get_translation_matrix(v):
    return np.array([[1, 0, 0, v[0]], [0, 1, 0, v[1]], [0, 0, 1, v[2]], [0, 0, 0, 1]])

v_rect = [[1, 2, 0], [4, 2, 0], [4, 5, 0], [1, 5, 0]]
pivot = [3, 3, 0]

T_to = get_translation_matrix([-p for p in pivot])
T_back = get_translation_matrix(pivot)
Rx = get_rotation_x(30)
Ry = get_rotation_y(60)

M_total = T_back @ Rx @ Ry @ T_to

scene = Scene(
    image_size=(8, 8),
    coordinate_rect=(0, 0, -2, 6, 6, 4),
    title="Завдання 9: Perspective Simulation",
    grid_show=True
)

rect_init = Rectangle(v_rect, color="grey", alpha=0.2)
rect_final = Rectangle(v_rect, color="purple", alpha=0.8)
rect_final.transformation = M_total

scene["initial"] = rect_init
scene["final"] = rect_final

scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task9_visualization.png")

print("Матриця імітації перспективи M:\n", M_total)