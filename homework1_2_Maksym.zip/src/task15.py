import numpy as np

def decompose_affine_matrix(M):
    """
    Декомпозиція афінної матриці 4x4 на масштаб, кут та вісь обертання.
    """

    translation = M[0:3, 3]
    
    scales = np.linalg.norm(M[0:3, 0:3], axis=0)
    

    R = M[0:3, 0:3] / scales
    

    cos_theta = (np.trace(R) - 1) / 2
    angle_rad = np.arccos(np.clip(cos_theta, -1.0, 1.0))
    angle_deg = np.degrees(angle_rad)
    

    if angle_deg < 1e-6:
        axis = np.array([1, 0, 0])  
    else:
        axis = np.array([
            R[2, 1] - R[1, 2],
            R[0, 2] - R[2, 0],
            R[1, 0] - R[0, 1]
        ])
        axis /= np.linalg.norm(axis)
        
    return scales, angle_deg, axis

M_final = np.array([
    [2, 0, 0, -4],
    [0, 0, -2, 3],
    [0, 2, 0, 1],
    [0, 0, 0, 1]
])

scales, angle, axis = decompose_affine_matrix(M_final)
print(f"Масштабні коефіцієнти: {scales}")
print(f"Кут повороту: {angle:.1f}°")
print(f"Одиниця осі обертання: {axis}")