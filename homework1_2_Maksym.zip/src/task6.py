import matplotlib
matplotlib.use("Agg")
import numpy as np
from src.engine.model.Cube import Cube
from src.engine.scene.Scene import Scene

def get_translation_matrix(dx, dy, dz):
    return np.array([[1, 0, 0, dx], [0, 1, 0, dy], [0, 0, 1, dz], [0, 0, 0, 1]])

def get_rotation_y(angle_deg):
    theta = np.radians(angle_deg)
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1]])

pivot = (2, 0, 3)

T_to_origin = get_translation_matrix(-pivot[0], -pivot[1], -pivot[2])
Ry = get_rotation_y(45)
T_back = get_translation_matrix(pivot[0], pivot[1], pivot[2])

M_pivot = T_back @ Ry @ T_to_origin

T_final = get_translation_matrix(-1, 2, 4)

M_total = T_final @ M_pivot

scene = Scene(
    image_size=(10, 10),
    coordinate_rect=(-4, -1, -1, 4, 6, 8),
    title="Завдання 6: Обертання навколо опорної точки (2,0,3)",
    grid_show=True
)

cube_init = Cube(alpha=0.1, color="grey")
cube_final = Cube(alpha=0.7, color="cyan", edge_color="blue")

cube_final.pivot(*pivot)
cube_final.show_pivot()

cube_final.transformation = M_total

scene["initial"] = cube_init
scene["final"] = cube_final

scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task6_visualization.png")

print("Фінальна матриця M_total:\n", M_total)