import matplotlib
matplotlib.use("Agg")
import numpy as np
from src.engine.model.Cube import Cube
from src.engine.scene.Scene import Scene

def get_rotation_matrix(axis, angle_deg):
    axis = np.array(axis, dtype=float)
    axis /= np.linalg.norm(axis)
    theta = np.radians(angle_deg)
    c, s = np.cos(theta), np.sin(theta)
    C = 1 - c
    return np.array([
        [c + axis[0]**2 * C, axis[0]*axis[1]*C - axis[2]*s, axis[0]*axis[2]*C + axis[1]*s, 0],
        [axis[1]*axis[0]*C + axis[2]*s, c + axis[1]**2 * C, axis[1]*axis[2]*C - axis[0]*s, 0],
        [axis[2]*axis[0]*C - axis[1]*s, axis[2]*axis[1]*C + axis[0]*s, c + axis[2]**2 * C, 0],
        [0, 0, 0, 1]
    ])

def get_translation_matrix(v):
    return np.array([[1, 0, 0, v[0]], [0, 1, 0, v[1]], [0, 0, 1, v[2]], [0, 0, 0, 1]])

Rx = get_rotation_matrix([1, 0, 0], 20)
Ry = get_rotation_matrix([0, 1, 0], 35)
Rz = get_rotation_matrix([0, 0, 1], 50)

R_combined = Rz @ Ry @ Rx
T = get_translation_matrix([1, 3, -2])
M = T @ R_combined

scene = Scene(
    image_size=(8, 8),
    coordinate_rect=(-2, -1, -4, 5, 6, 2),
    title="Завдання 4: Обертання ZYX",
    grid_show=True
)

cube_init = Cube(alpha=0.1, color="grey")
cube_final = Cube(alpha=0.7, color="yellow", edge_color="orange")
cube_final.transformation = M

scene["initial"] = cube_init
scene["final"] = cube_final

scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task4_visualization.png")

print("Фінальна матриця M:\n", M)