import matplotlib
matplotlib.use("Agg")
import numpy as np
from src.engine.model.SimplePolygon import SimplePolygon
from src.engine.model.Model import Model
from src.engine.scene.Scene import Scene

# Клас для трикутника
class Triangle(Model):
    def __init__(self, vertices, color="cyan", alpha=1.0):
        super().__init__()
        self.polygons = [SimplePolygon(*vertices, color=color, alpha=alpha)]
    
    def draw_model(self, plt_axis):
        for polygon in self.polygons:
            polygon.transformation = self.transformation
            polygon.draw(plt_axis)

def get_rotation_matrix_axis(axis, angle_deg):
    axis = np.array(axis, dtype=float)
    axis /= np.linalg.norm(axis)
    theta = np.radians(angle_deg)
    c, s = np.cos(theta), np.sin(theta)
    C = 1 - c
    return np.array([
        [c + axis[0]**2 * C, axis[0]*axis[1]*C - axis[2]*s, axis[0]*axis[2]*C + axis[1]*s, 0],
        [axis[1]*axis[0]*C + axis[2]*s, c + axis[1]**2 * C, axis[1]*axis[2]*C - axis[0]*s, 0],
        [axis[2]*axis[0]*C - axis[1]*s, axis[2]*axis[1]*C + axis[0]*s, c + axis[2]**2 * C, 0],
        [0, 0, 0, 1]
    ])

def get_translation_matrix(v):
    return np.array([[1, 0, 0, v[0]], [0, 1, 0, v[1]], [0, 0, 1, v[2]], [0, 0, 0, 1]])

v_triangle = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
pivot_point = [2, 3, 4]
rot_axis = [1, 1, 1]

T_to = get_translation_matrix([-p for p in pivot_point])
R = get_rotation_matrix_axis(rot_axis, 90)
T_back = get_translation_matrix(pivot_point)
T_final = get_translation_matrix([0, -3, 2])

M_total = T_final @ T_back @ R @ T_to

# 3. Сцена
scene = Scene(
    image_size=(10, 10),
    coordinate_rect=(0, -2, 0, 8, 8, 12),
    title="Завдання 8: Обертання навколо зміщеної осі",
    grid_show=True
)

tri_init = Triangle(v_triangle, color="grey", alpha=0.3)
tri_final = Triangle(v_triangle, color="blue", alpha=0.9)
tri_final.transformation = M_total

scene["initial"] = tri_init
scene["final"] = tri_final

scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task8_visualization.png")

print("Фінальна матриця M_total:\n", M_total)