import matplotlib
matplotlib.use("Agg")
import numpy as np
from src.engine.model.Cube import Cube
from src.engine.scene.Scene import Scene

def get_translation_matrix(v):
    return np.array([[1, 0, 0, v[0]], [0, 1, 0, v[1]], [0, 0, 1, v[2]], [0, 0, 0, 1]])

def get_scale_matrix(sx, sy, sz):
    return np.array([[sx, 0, 0, 0], [0, sy, 0, 0], [0, 0, sz, 0], [0, 0, 0, 1]])

def get_rotation_y(angle_deg):
    theta = np.radians(angle_deg)
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1]])

pivot = (1, 1, 1)
T_to = get_translation_matrix([-p for p in pivot])
T_back = get_translation_matrix(pivot)

Ms = T_back @ get_scale_matrix(2, 1, 1) @ T_to

Mr = T_back @ get_rotation_y(45) @ T_to

Mt = get_translation_matrix([-3, 4, 2])

M_total = Mt @ Mr @ Ms

scene = Scene(
    image_size=(10, 10),
    coordinate_rect=(-6, -1, -1, 3, 7, 7),
    title="Завдання 10: Комплексна трансформація (Scale -> Rotate -> Translate)",
    grid_show=True
)

cube_init = Cube(alpha=0.1, color="grey")
cube_final = Cube(alpha=0.7, color="teal", edge_color="darkblue")

# Візуалізуємо опорну точку
cube_final.pivot(*pivot)
cube_final.show_pivot()
cube_final.transformation = M_total

scene["initial"] = cube_init
scene["final"] = cube_final

scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task10_visualization.png")

print("Матриця Ms:\n", Ms)
print("\nМатриця Mr:\n", Mr)
print("\nПідсумкова матриця M_total:\n", M_total)