import matplotlib
matplotlib.use("Agg") # Для роботи в Codespaces
import numpy as np
from src.engine.model.Cube import Cube
from src.engine.scene.Scene import Scene

def get_rotation_matrix_axis(axis, angle_deg):
    axis = np.array(axis, dtype=float)
    axis /= np.linalg.norm(axis)
    theta = np.radians(angle_deg)
    c, s = np.cos(theta), np.sin(theta)
    C = 1 - c
    return np.array([
        [c + axis[0]**2 * C, axis[0]*axis[1]*C - axis[2]*s, axis[0]*axis[2]*C + axis[1]*s, 0],
        [axis[1]*axis[0]*C + axis[2]*s, c + axis[1]**2 * C, axis[1]*axis[2]*C - axis[0]*s, 0],
        [axis[2]*axis[0]*C - axis[1]*s, axis[2]*axis[1]*C + axis[0]*s, c + axis[2]**2 * C, 0],
        [0, 0, 0, 1]
    ])

def get_scale_matrix(sx, sy, sz):
    return np.array([[sx, 0, 0, 0], [0, sy, 0, 0], [0, 0, sz, 0], [0, 0, 0, 1]])

def get_translation_matrix(dx, dy, dz):
    return np.array([[1, 0, 0, dx], [0, 1, 0, dy], [0, 0, 1, dz], [0, 0, 0, 1]])


scene = Scene(
    image_size=(10, 10),
    coordinate_rect=(-5, -1, -1, 3, 6, 8),
    title="Завдання 2: Scale -> Rotate (Euler) -> Translate",
    grid_show=True
)

S = get_scale_matrix(2, 0.5, 1)

# 2. Обертання Ейлера XYZ (30, 45, 60)
Rx = get_rotation_matrix_axis([1, 0, 0], 30)
Ry = get_rotation_matrix_axis([0, 1, 0], 45)
Rz = get_rotation_matrix_axis([0, 0, 1], 60)
R = Rz @ Ry @ Rx


T = get_translation_matrix(-3, 2, 5)

# Композиція M = T * R * S
M = T @ R @ S


cube_initial = Cube(alpha=0.1, color="grey")
cube_final = Cube(alpha=0.7, color="magenta", edge_color="purple")
cube_final.transformation = M

scene["initial"] = cube_initial
scene["final"] = cube_final

scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task2_visualization.png")

print("Фінальна матриця трансформації M:\n", M)