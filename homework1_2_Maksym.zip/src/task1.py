import matplotlib
matplotlib.use("Agg")
import numpy as np
from src.engine.model.Cube import Cube
from src.engine.scene.Scene import Scene

def get_rotation_matrix():
    axis = np.array([1, 1, 0], dtype=float)
    axis /= np.linalg.norm(axis)
    theta = np.radians(45)
    c, s = np.cos(theta), np.sin(theta)
    C = 1 - c
    return np.array([
        [c + axis[0]**2 * C, axis[0]*axis[1]*C - axis[2]*s, axis[0]*axis[2]*C + axis[1]*s, 0],
        [axis[1]*axis[0]*C + axis[2]*s, c + axis[1]**2 * C, axis[1]*axis[2]*C - axis[0]*s, 0],
        [axis[2]*axis[0]*C - axis[1]*s, axis[2]*axis[1]*C + axis[0]*s, c + axis[2]**2 * C, 0],
        [0, 0, 0, 1]
    ])

def get_translation_matrix():
    return np.array([[1,0,0,2], [0,1,0,-1], [0,0,1,3], [0,0,0,1]])

scene = Scene(
    image_size=(10, 10),
    coordinate_rect=(-1, -2, -1, 6, 6, 6),
    title="Завдання 1: Ротація + Трансляція",
    grid_show=True
)

M = get_translation_matrix() @ get_rotation_matrix()

cube1 = Cube(alpha=0.1, color="grey") # Початковий
cube2 = Cube(alpha=0.8, color="cyan") # Фінальний
cube2.transformation = M

scene["start"] = cube1
scene["end"] = cube2

scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task1_visualization.png")
print("Матриця M:\n", M)