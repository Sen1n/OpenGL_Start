import matplotlib
matplotlib.use("Agg")
import numpy as np
from src.engine.model.Model import Model
from src.engine.model.SimplePolygon import SimplePolygon
from src.engine.scene.Scene import Scene

class Tetrahedron(Model):
    def __init__(self, color="cyan", alpha=1.0):
        super().__init__()
        self.polygons = []
        v = [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]]
        faces = [[v[0],v[1],v[2]], [v[0],v[1],v[3]], [v[0],v[2],v[3]], [v[1],v[2],v[3]]]
        for face in faces:
            self.polygons.append(SimplePolygon(*face, color=color, alpha=alpha))

    def draw_model(self, plt_axis):
        for polygon in self.polygons:
            polygon.transformation = self.transformation
            polygon.pivot(self._pivot)
            polygon.draw(plt_axis)

def rx(deg):
    c, s = np.cos(np.radians(deg)), np.sin(np.radians(deg))
    return np.array([[1,0,0,0], [0,c,-s,0], [0,s,c,0], [0,0,0,1]])

def rz(deg):
    c, s = np.cos(np.radians(deg)), np.sin(np.radians(deg))
    return np.array([[c,-s,0,0], [s,c,0,0], [0,0,1,0], [0,0,0,1]])

def ty(d):
    return np.array([[1,0,0,0], [0,1,0,d], [0,0,1,0], [0,0,0,1]])



M1 = rx(45)
M2 = M1 @ ty(2)
M3 = M2 @ rz(30)

scene = Scene(image_size=(10,10), coordinate_rect=(-2,-1,-1,4,5,5), title="Завдання 13: Локальні трансформації")

tetra_init = Tetrahedron(color="grey", alpha=0.1)
tetra_final = Tetrahedron(color="lime", alpha=0.7)
tetra_final.transformation = M3 # Фінальний результат

scene["init"] = tetra_init
scene["final"] = tetra_final

scene._prepare()
scene._draw_frames() 
scene.figure.savefig("task13_visualization.png")

print("Фінальна матриця M3:\n", M3)